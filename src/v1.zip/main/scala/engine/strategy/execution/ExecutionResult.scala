package engine.strategy.execution

import engine.context.ProblemContext
import engine.strategy.trace.StrategyTrace

final case class ExecutionResult(
  context: ProblemContext,
  trace: StrategyTrace,
  success: Boolean,
  error: Option[ExecutionError] = None,
  remainingBudget: ExecutionBudget
)

object ExecutionResult:
  def success(context: ProblemContext, trace: StrategyTrace, budget: ExecutionBudget): ExecutionResult =
    ExecutionResult(context, trace, success = true, error = None, remainingBudget = budget)

  def failure(context: ProblemContext, trace: StrategyTrace, error: ExecutionError, budget: ExecutionBudget): ExecutionResult =
    ExecutionResult(context, trace, success = false, error = Some(error), remainingBudget = budget)
