package engine.problem

import engine.context.ContextValue

class JsonProgrammingProblemFunctorSpec extends munit.FunSuite:
  test("converts direct JSONic programming problem into normalized ProblemContext"):
    val result = JsonProgrammingProblemFunctor.map(ProgrammingProblemExamples.twoSumJsonic)

    assert(result.isRight, result.left.toOption.map(_.toString).getOrElse(""))
    val context = result.toOption.get

    assertEquals(context.facts("profile"), ContextValue.StringValue("programming-problem/v1"))
    assertEquals(context.facts("problem.id"), ContextValue.StringValue("two-sum-basic"))
    assertEquals(context.facts("problem.kind"), ContextValue.StringValue("algorithm"))
    assertEquals(context.facts("problem.domain"), ContextValue.StringValue("arrays"))
    assert(context.goals.contains("derive solution strategy"))
    assert(context.unknowns.contains("solution.algorithm"))

  test("converts array into ProblemSpace"):
    val input = s"""
      {
        "problems": [
          ${ProgrammingProblemExamples.twoSumJsonic},
          {
            "id": "valid-parentheses",
            "kind": "algorithm",
            "domain": "stack",
            "title": "Valid Parentheses",
            "description": "Determine whether all brackets are closed in the correct order.",
            "input.spec": { "s": "String" },
            "output.spec": "Boolean"
          }
        ]
      }
    """

    val result = JsonProblemSpaceFunctor.map(input)

    assert(result.isRight, result.left.toOption.map(_.toString).getOrElse(""))
    assertEquals(result.toOption.get.size, 2)

  test("accepts existing ProblemContext tagged JSON"):
    val input = """
      {
        "facts": {
          "problem.id": { "StringValue": "p1" },
          "title": { "StringValue": "Already Normalized" },
          "description": { "StringValue": "A context-shaped problem." },
          "problem.kind": { "StringValue": "meta" }
        },
        "unknowns": {},
        "goals": ["test goal"],
        "artifacts": {}
      }
    """

    val result = JsonProgrammingProblemFunctor.map(input)

    assert(result.isRight, result.left.toOption.map(_.toString).getOrElse(""))
    assertEquals(result.toOption.get.goals, Vector("test goal"))
    assertEquals(result.toOption.get.facts("problem.id"), ContextValue.StringValue("p1"))
