package engine.problem

import engine.context.{ContextValue, ProblemContext}

/** Standard vocabulary for programming-problem contexts. */
object ProgrammingProblemKeys:
  val Profile = "profile"
  val Id = "problem.id"
  val Kind = "problem.kind"
  val Domain = "problem.domain"
  val Title = "title"
  val Description = "description"
  val InputSpec = "input.spec"
  val OutputSpec = "output.spec"
  val Constraints = "constraints"
  val Examples = "examples"
  val EdgeCases = "edgeCases"
  val ComplexityTarget = "complexity.target"
  val LanguageTarget = "language.target"
  val RequiredBehavior = "requiredBehavior"
  val AllowedTechniques = "allowedTechniques"
  val ForbiddenTechniques = "forbiddenTechniques"
  val EvaluationTests = "evaluation.tests"
  val SolutionAlgorithm = "solution.algorithm"
  val SolutionCode = "solution.code"
  val CorrectnessProof = "proof.correctness"
  val MissingEdgeCases = "missing.edgeCases"

final case class ProblemExample(
  input: ContextValue,
  output: ContextValue,
  explanation: Option[String] = None
):
  def toContextValue: ContextValue =
    val base = Map(
      "input" -> input,
      "output" -> output
    )
    ContextValue.MapValue(explanation.fold(base)(value => base + ("explanation" -> ContextValue.StringValue(value))))

/**
 * Typed programming-problem profile layered on top of ProblemContext.
 *
 * This keeps the strategy engine generic while giving programming problems a stable
 * vocabulary for algorithms, data-structures, parsers, refactors, systems tasks, etc.
 */
final case class ProgrammingProblemProfile(
  id: String,
  title: String,
  description: String,
  kind: String,
  domain: Option[String] = None,
  inputSpec: ContextValue = ContextValue.MapValue(Map.empty),
  outputSpec: ContextValue = ContextValue.StringValue("unspecified"),
  constraints: Vector[String] = Vector.empty,
  examples: Vector[ProblemExample] = Vector.empty,
  edgeCases: Vector[String] = Vector.empty,
  complexityTarget: Map[String, ContextValue] = Map.empty,
  languageTarget: Option[String] = None,
  requiredBehavior: Vector[String] = Vector.empty,
  allowedTechniques: Vector[String] = Vector.empty,
  forbiddenTechniques: Vector[String] = Vector.empty,
  evaluationTests: Vector[ContextValue] = Vector.empty,
  unknowns: Map[String, ContextValue] = Map.empty,
  goals: Vector[String] = Vector.empty,
  artifacts: Map[String, ContextValue] = Map.empty,
  extraFacts: Map[String, ContextValue] = Map.empty
):
  import ProgrammingProblemKeys.*

  def toProblemContext: ProblemContext =
    val canonicalFacts = Map(
      Profile -> ContextValue.StringValue("programming-problem/v1"),
      Id -> ContextValue.StringValue(id),
      Kind -> ContextValue.StringValue(kind),
      Title -> ContextValue.StringValue(title),
      Description -> ContextValue.StringValue(description),
      InputSpec -> inputSpec,
      OutputSpec -> outputSpec,
      Constraints -> ContextValue.ListValue(constraints.map(ContextValue.StringValue.apply)),
      Examples -> ContextValue.ListValue(examples.map(_.toContextValue)),
      EdgeCases -> ContextValue.ListValue(edgeCases.map(ContextValue.StringValue.apply)),
      ComplexityTarget -> ContextValue.MapValue(complexityTarget),
      RequiredBehavior -> ContextValue.ListValue(requiredBehavior.map(ContextValue.StringValue.apply)),
      AllowedTechniques -> ContextValue.ListValue(allowedTechniques.map(ContextValue.StringValue.apply)),
      ForbiddenTechniques -> ContextValue.ListValue(forbiddenTechniques.map(ContextValue.StringValue.apply)),
      EvaluationTests -> ContextValue.ListValue(evaluationTests)
    ) ++ domain.map(value => Domain -> ContextValue.StringValue(value))
      ++ languageTarget.map(value => LanguageTarget -> ContextValue.StringValue(value))

    val canonicalUnknowns = Map(
      SolutionAlgorithm -> ContextValue.StringValue("Unknown"),
      SolutionCode -> ContextValue.StringValue("Unknown"),
      CorrectnessProof -> ContextValue.StringValue("Unknown"),
      MissingEdgeCases -> ContextValue.StringValue("Unknown")
    ) ++ unknowns

    val canonicalGoals =
      if goals.nonEmpty then goals
      else Vector(
        "understand input and output specification",
        "derive solution strategy",
        "generate implementation",
        "generate tests",
        "validate constraints and edge cases"
      )

    ProblemContext(
      facts = canonicalFacts ++ extraFacts,
      unknowns = canonicalUnknowns,
      goals = canonicalGoals,
      artifacts = artifacts
    )

object ProgrammingProblemProfile:
  def fromContext(context: ProblemContext): Either[ProblemFormatError, ProgrammingProblemProfile] =
    def stringFact(key: String): Option[String] = context.facts.get(key).flatMap(_.asStringOption)
    def stringListFact(key: String): Vector[String] =
      context.facts.get(key).flatMap(_.asVectorOption).toVector.flatten.flatMap(_.asStringOption)

    val id = stringFact(ProgrammingProblemKeys.Id).orElse(stringFact("id"))
    val title = stringFact(ProgrammingProblemKeys.Title)
    val description = stringFact(ProgrammingProblemKeys.Description)
    val kind = stringFact(ProgrammingProblemKeys.Kind)

    (id, title, description, kind) match
      case (Some(problemId), Some(problemTitle), Some(problemDescription), Some(problemKind)) =>
        Right(
          ProgrammingProblemProfile(
            id = problemId,
            title = problemTitle,
            description = problemDescription,
            kind = problemKind,
            domain = stringFact(ProgrammingProblemKeys.Domain),
            inputSpec = context.facts.getOrElse(ProgrammingProblemKeys.InputSpec, ContextValue.MapValue(Map.empty)),
            outputSpec = context.facts.getOrElse(ProgrammingProblemKeys.OutputSpec, ContextValue.StringValue("unspecified")),
            constraints = stringListFact(ProgrammingProblemKeys.Constraints),
            edgeCases = stringListFact(ProgrammingProblemKeys.EdgeCases),
            languageTarget = stringFact(ProgrammingProblemKeys.LanguageTarget),
            requiredBehavior = stringListFact(ProgrammingProblemKeys.RequiredBehavior),
            allowedTechniques = stringListFact(ProgrammingProblemKeys.AllowedTechniques),
            forbiddenTechniques = stringListFact(ProgrammingProblemKeys.ForbiddenTechniques),
            unknowns = context.unknowns,
            goals = context.goals,
            artifacts = context.artifacts,
            extraFacts = context.facts -- Set(
              ProgrammingProblemKeys.Profile,
              ProgrammingProblemKeys.Id,
              ProgrammingProblemKeys.Kind,
              ProgrammingProblemKeys.Domain,
              ProgrammingProblemKeys.Title,
              ProgrammingProblemKeys.Description,
              ProgrammingProblemKeys.InputSpec,
              ProgrammingProblemKeys.OutputSpec,
              ProgrammingProblemKeys.Constraints,
              ProgrammingProblemKeys.Examples,
              ProgrammingProblemKeys.EdgeCases,
              ProgrammingProblemKeys.ComplexityTarget,
              ProgrammingProblemKeys.LanguageTarget,
              ProgrammingProblemKeys.RequiredBehavior,
              ProgrammingProblemKeys.AllowedTechniques,
              ProgrammingProblemKeys.ForbiddenTechniques,
              ProgrammingProblemKeys.EvaluationTests
            )
          )
        )
      case _ =>
        Left(ProblemFormatError("ProblemContext is missing required programming profile facts: problem.id/id, title, description, problem.kind"))
