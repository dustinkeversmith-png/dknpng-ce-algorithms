package engine.integration

import engine.context.{ContextValue, ProblemContext}
import engine.strategy.examples.ExampleRegistries
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.model.*

class BasicStrategyAssemblySpec extends munit.FunSuite:
  test("finite search strategy assembly passes first sprint scenario"):
    val context = ProblemContext(
      facts = Map(
        "candidates" -> ContextValue.list("a", "b", "c", "d"),
        "target" -> ContextValue.StringValue("c")
      )
    )

    val assembly = CompositeStrategy(
      id = StrategyId("finite-search-assembly"),
      name = "Finite Search Assembly",
      kind = StrategyKind.Search,
      compositionMode = CompositionMode.Sequence,
      children = Vector(
        AtomicStrategy(StrategyId("add-type"), "Add problem type", StrategyKind.Meta, "add-problem-type"),
        AtomicStrategy(StrategyId("subgoal"), "Generate subgoal", StrategyKind.Meta, "generate-search-subgoal"),
        AtomicStrategy(StrategyId("search"), "Basic search", StrategyKind.Search, "basic-search")
      )
    )

    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val result = executor.execute(assembly, context, ExecutionBudget(maxSteps = 20, maxDepth = 10))

    assert(result.success)
    assertEquals(result.context.facts("problem.type"), ContextValue.StringValue("finite-search"))
    assertEquals(result.context.facts("search.result"), ContextValue.StringValue("c"))
    assert(result.context.goals.contains("search candidates"))
    assert(result.trace.nonEmpty)
    assert(result.remainingBudget.remainingSteps < 20)
