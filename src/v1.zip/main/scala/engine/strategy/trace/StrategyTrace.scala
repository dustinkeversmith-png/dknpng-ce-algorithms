package engine.strategy.trace

final case class StrategyTrace(events: Vector[TraceEvent] = Vector.empty):
  def append(event: TraceEvent): StrategyTrace = copy(events = events :+ event)
  def ++(other: StrategyTrace): StrategyTrace = copy(events = events ++ other.events)
  def nonEmpty: Boolean = events.nonEmpty
  def size: Int = events.size

object StrategyTrace:
  val empty: StrategyTrace = StrategyTrace()
