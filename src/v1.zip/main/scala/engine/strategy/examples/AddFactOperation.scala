package engine.strategy.examples

import engine.context.{ContextValue, ProblemContext, ProblemContextDelta}
import engine.strategy.execution.ExecutionError
import engine.strategy.model.StrategyOperation

final case class AddFactOperation(id: String, key: String, value: ContextValue) extends StrategyOperation:
  override def description: String = s"Add fact $key"
  override def run(context: ProblemContext): Either[ExecutionError, ProblemContextDelta] =
    Right(ProblemContextDelta(addFacts = Map(key -> value)))
