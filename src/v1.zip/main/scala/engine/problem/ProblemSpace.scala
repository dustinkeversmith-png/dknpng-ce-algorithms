package engine.problem

import engine.context.ProblemContext
import JsonValue.*

// It seems like a problem space is many problem contexts.
// A problem space should be one a either the set of ProblemContexts with either fix and unfixed variables or ranges, or combinations
// of provided subsets
// While a ProblemSubSpace would be like the space of problems with inputs, or other variable fixes and generated values to use 
// to solve example problems.
final case class ProblemSpace(problems: Vector[ProblemContext]):
  def size: Int = problems.size
  def isEmpty: Boolean = problems.isEmpty

/** Converts a JSON/JSONic array or { problems: [...] } object into many contexts. */
object JsonProblemSpaceFunctor extends ProblemFormatFunctor[String, ProblemSpace]:
  def map(input: String): Either[ProblemFormatError, ProblemSpace] =
    JsonParser.parseJsonic(input).flatMap(fromJsonValue)

  def fromJsonValue(json: JsonValue): Either[ProblemFormatError, ProblemSpace] =
    json match
      case JsonArray(values) => mapProblems(values)
      case JsonObject(values) if values.contains("problems") =>
        values("problems") match
          case JsonArray(items) => mapProblems(items)
          case _ => Left(ProblemFormatError("Expected 'problems' to be an array"))
      case single => JsonProgrammingProblemFunctor.fromJsonValue(single).map(ctx => ProblemSpace(Vector(ctx)))

  private def mapProblems(values: Vector[JsonValue]): Either[ProblemFormatError, ProblemSpace] =
    values.zipWithIndex.foldLeft[Either[ProblemFormatError, Vector[ProblemContext]]](Right(Vector.empty)) {
      case (Left(err), _) => Left(err)
      case (Right(acc), (json, idx)) =>
        JsonProgrammingProblemFunctor.fromJsonValue(json) match
          case Right(context) => Right(acc :+ context)
          case Left(err) => Left(ProblemFormatError(s"Invalid problem at index $idx: ${err.message}", err.path, err.cause))
    }.map(ProblemSpace.apply)
