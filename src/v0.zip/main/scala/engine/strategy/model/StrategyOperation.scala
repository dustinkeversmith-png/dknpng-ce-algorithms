package engine.strategy.model

import engine.context.{ProblemContext, ProblemContextDelta}
import engine.strategy.execution.ExecutionError

trait StrategyOperation:
  def id: String
  def description: String = id
  def run(context: ProblemContext): Either[ExecutionError, ProblemContextDelta]
