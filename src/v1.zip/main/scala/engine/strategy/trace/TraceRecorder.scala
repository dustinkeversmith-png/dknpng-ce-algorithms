package engine.strategy.trace

object TraceRecorder:
  def empty: StrategyTrace = StrategyTrace.empty
  def record(trace: StrategyTrace, event: TraceEvent): StrategyTrace = trace.append(event)
