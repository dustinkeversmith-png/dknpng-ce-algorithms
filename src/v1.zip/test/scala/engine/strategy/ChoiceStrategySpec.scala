package engine.strategy

import engine.context.{ContextValue, ProblemContext}
import engine.strategy.examples.ExampleRegistries
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.model.*
import engine.strategy.trace.TraceEvent

class ChoiceStrategySpec extends munit.FunSuite:
  test("selects and executes first child in V1"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val strategy = CompositeStrategy(
      StrategyId("choice"), "Choice", StrategyKind.Meta, CompositionMode.Choice,
      Vector(
        AtomicStrategy(StrategyId("type"), "type", StrategyKind.Meta, "add-problem-type"),
        AtomicStrategy(StrategyId("subgoal"), "subgoal", StrategyKind.Meta, "generate-search-subgoal")
      )
    )

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(10, 10))

    assert(result.success)
    assert(result.context.facts.contains("problem.type"))
    assert(result.context.goals.isEmpty)
    assert(result.trace.events.exists(_.isInstanceOf[TraceEvent.ChoiceSelected]))
