package engine.strategy.execution

sealed trait ExecutionError:
  def message: String

object ExecutionError:
  final case class OperationNotFound(operationId: String) extends ExecutionError:
    def message: String = s"Operation not found: $operationId"

  final case class OperationFailed(operationId: String, reason: String) extends ExecutionError:
    def message: String = s"Operation failed: $operationId. $reason"

  final case class UnsupportedComposition(mode: String) extends ExecutionError:
    def message: String = s"Unsupported composition mode: $mode"

  final case class BudgetExceeded(message: String) extends ExecutionError
  final case class DepthExceeded(message: String) extends ExecutionError
  final case class EmptyComposite(message: String) extends ExecutionError
