package engine.strategy.registry

import engine.strategy.model.StrategyOperation

final case class OperationRegistry(
  operations: Map[String, StrategyOperation] = Map.empty
):
  def register(operation: StrategyOperation): Either[String, OperationRegistry] =
    if operations.contains(operation.id) then Left(s"Operation already registered: ${operation.id}")
    else Right(copy(operations = operations + (operation.id -> operation)))

  def registerUnsafe(operation: StrategyOperation): OperationRegistry =
    copy(operations = operations + (operation.id -> operation))

  def get(id: String): Option[StrategyOperation] =
    operations.get(id)

object OperationRegistry:
  val empty: OperationRegistry = OperationRegistry()
  def withOperations(ops: StrategyOperation*): OperationRegistry =
    ops.foldLeft(empty)((registry, op) => registry.registerUnsafe(op))
