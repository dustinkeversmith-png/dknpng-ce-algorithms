package engine.strategy

import engine.context.ProblemContext
import engine.strategy.examples.ExampleRegistries
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.model.*

class BudgetSpec extends munit.FunSuite:
  test("consumes step per atomic execution"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val strategy = AtomicStrategy(StrategyId("type"), "type", StrategyKind.Meta, "add-problem-type")

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(3, 3))
    assert(result.success)
    assertEquals(result.remainingBudget.remainingSteps, 2)

  test("fails when max steps reached"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val strategy = AtomicStrategy(StrategyId("type"), "type", StrategyKind.Meta, "add-problem-type")

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(0, 3))
    assert(!result.success)

  test("respects max depth for composite strategies"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val nested = CompositeStrategy(
      StrategyId("outer"), "outer", StrategyKind.Meta, CompositionMode.Sequence,
      Vector(CompositeStrategy(
        StrategyId("inner"), "inner", StrategyKind.Meta, CompositionMode.Sequence,
        Vector(AtomicStrategy(StrategyId("type"), "type", StrategyKind.Meta, "add-problem-type"))
      ))
    )

    val result = executor.execute(nested, ProblemContext(), ExecutionBudget(10, 1))
    assert(!result.success)
