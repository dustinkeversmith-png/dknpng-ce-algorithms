package engine.strategy.execution

import engine.context.ProblemContext
import engine.strategy.composition.*
import engine.strategy.model.*
import engine.strategy.registry.OperationRegistry
import engine.strategy.trace.{StrategyTrace, TraceEvent}

final class StrategyInterpreter(operationRegistry: OperationRegistry) extends StrategyExecutor:
  override def execute(strategy: Strategy, context: ProblemContext, budget: ExecutionBudget): ExecutionResult =
    strategy match
      case atomic: AtomicStrategy => executeAtomic(atomic, context, budget)
      case composite: CompositeStrategy => executeComposite(composite, context, budget)



  // Since it appears like strategies and the operations actually should be decoupled the strategic operations should be called
  // ProblemStrategies, and the Operations should be called ProblemStrategicOperations
  // Then the actual steps or discovered solution topology should be SolutionOperations and SolutionStrategies
  // Problem need to rename this to problemStrategyInterpreter and put it into the interpreters folder. same with executor
  private def executeAtomic(strategy: AtomicStrategy, context: ProblemContext, budget: ExecutionBudget): ExecutionResult =
    val started = StrategyTrace.empty.append(TraceEvent.StrategyStarted(strategy.id, strategy.name))

    budget.consumeStep match
      case Left(error) =>
        ExecutionResult.failure(context, started.append(TraceEvent.StrategyFailed(strategy.id, error.message)), error, budget)
      case Right(afterStepBudget) =>
        val withBudgetTrace = started.append(TraceEvent.BudgetConsumed(strategy.id, afterStepBudget.remainingSteps, afterStepBudget.currentDepth))
        operationRegistry.get(strategy.operationId) match
          case None =>
            val error = ExecutionError.OperationNotFound(strategy.operationId)
            ExecutionResult.failure(context, withBudgetTrace.append(TraceEvent.StrategyFailed(strategy.id, error.message)), error, afterStepBudget)
          case Some(operation) =>
            operation.run(context) match
              case Left(error) =>
                ExecutionResult.failure(context, withBudgetTrace.append(TraceEvent.StrategyFailed(strategy.id, error.message)), error, afterStepBudget)
              case Right(delta) =>
                val updatedContext = context.applyDelta(delta)
                val trace = withBudgetTrace
                  .append(TraceEvent.DeltaApplied(strategy.id, delta))
                  .append(TraceEvent.StrategySucceeded(strategy.id))
                ExecutionResult.success(updatedContext, trace, afterStepBudget)

  private def executeComposite(strategy: CompositeStrategy, context: ProblemContext, budget: ExecutionBudget): ExecutionResult =
    val started = StrategyTrace.empty.append(TraceEvent.StrategyStarted(strategy.id, strategy.name))

    val enteredBudgetEither = for
      afterStep <- budget.consumeStep
      afterDepth <- afterStep.enterDepth
    yield afterDepth

    enteredBudgetEither match
      case Left(error) =>
        ExecutionResult.failure(context, started.append(TraceEvent.StrategyFailed(strategy.id, error.message)), error, budget)
      case Right(enteredBudget) =>
        val budgetTrace = started.append(TraceEvent.BudgetConsumed(strategy.id, enteredBudget.remainingSteps, enteredBudget.currentDepth))
        val compositionResult = strategy.compositionMode match
          case CompositionMode.Sequence => SequenceExecutor.execute(strategy, context, enteredBudget, this)
          case CompositionMode.Fallback => FallbackExecutor.execute(strategy, context, enteredBudget, this)
          case CompositionMode.Choice => ChoiceExecutor.execute(strategy, context, enteredBudget, this)
          case CompositionMode.Repeat => RepeatExecutor.execute(strategy, context, enteredBudget, this)
          case CompositionMode.MeasureThenSelect => MeasureThenSelectExecutor.execute(strategy, context, enteredBudget, this)
          case other => ExecutionResult.failure(context, StrategyTrace.empty, ExecutionError.UnsupportedComposition(other.toString), enteredBudget)

        val completedBudget = compositionResult.remainingBudget.exitDepth
        val completedTrace =
          if compositionResult.success then
            budgetTrace ++ compositionResult.trace.append(TraceEvent.StrategySucceeded(strategy.id))
          else
            val reason = compositionResult.error.map(_.message).getOrElse("Composite failed")
            budgetTrace ++ compositionResult.trace.append(TraceEvent.StrategyFailed(strategy.id, reason))

        compositionResult.copy(trace = completedTrace, remainingBudget = completedBudget)
