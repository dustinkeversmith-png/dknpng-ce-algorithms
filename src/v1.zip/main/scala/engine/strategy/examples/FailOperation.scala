package engine.strategy.examples

import engine.context.{ProblemContext, ProblemContextDelta}
import engine.strategy.execution.ExecutionError
import engine.strategy.model.StrategyOperation

final case class FailOperation(id: String, reason: String = "Intentional failure") extends StrategyOperation:
  override def run(context: ProblemContext): Either[ExecutionError, ProblemContextDelta] =
    Left(ExecutionError.OperationFailed(id, reason))
