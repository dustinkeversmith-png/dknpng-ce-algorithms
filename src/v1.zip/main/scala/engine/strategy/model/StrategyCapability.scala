package engine.strategy.model

enum StrategyCapability:
  case AddsFact
  case ResolvesUnknown
  case GeneratesGoal
  case SearchesCandidates
  case ProducesArtifact
  case TranslatesRepresentation
  case BuildsCircuit
  case MeasuresContext
  case OptimizesCandidate
  case DecomposesProblem
  case MutatesStrategy
