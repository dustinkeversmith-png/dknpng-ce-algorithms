package engine.context

final case class ProblemContext(
  facts: Map[String, ContextValue] = Map.empty,
  unknowns: Map[String, ContextValue] = Map.empty,
  goals: Vector[String] = Vector.empty,
  artifacts: Map[String, ContextValue] = Map.empty
):
  def applyDelta(delta: ProblemContextDelta): ProblemContext =
    val removedFacts = facts -- delta.removeFacts
    val removedUnknowns = unknowns -- delta.removeUnknowns
    copy(
      facts = removedFacts ++ delta.addFacts,
      unknowns = removedUnknowns ++ delta.addUnknowns,
      goals = goals ++ delta.addGoals,
      artifacts = artifacts ++ delta.addArtifacts
    )

  def fact(key: String): Option[ContextValue] = facts.get(key)
  def unknown(key: String): Option[ContextValue] = unknowns.get(key)
  def artifact(key: String): Option[ContextValue] = artifacts.get(key)
