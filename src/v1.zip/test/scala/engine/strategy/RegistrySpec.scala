package engine.strategy

import engine.context.ContextValue
import engine.strategy.examples.AddFactOperation
import engine.strategy.model.{AtomicStrategy, StrategyId, StrategyKind}
import engine.strategy.registry.{OperationRegistry, StrategyRegistry}

class RegistrySpec extends munit.FunSuite:
  test("registers and retrieves operation"):
    val op = AddFactOperation("add", "x", ContextValue.StringValue("y"))
    val registry = OperationRegistry.empty.register(op).toOption.get
    assertEquals(registry.get("add"), Some(op))

  test("rejects duplicate operation ID"):
    val op1 = AddFactOperation("add", "x", ContextValue.StringValue("a"))
    val op2 = AddFactOperation("add", "x", ContextValue.StringValue("b"))
    val registry = OperationRegistry.empty.register(op1).toOption.get
    assert(registry.register(op2).isLeft)

  test("registers and retrieves strategy"):
    val strategy = AtomicStrategy(StrategyId("s"), "S", StrategyKind.Meta, "op")
    val registry = StrategyRegistry.empty.register(strategy).toOption.get
    assertEquals(registry.get(StrategyId("s")), Some(strategy))
