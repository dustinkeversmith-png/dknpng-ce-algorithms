package engine.strategy.composition

import engine.context.ProblemContext
import engine.strategy.execution.{ExecutionBudget, ExecutionError, ExecutionResult, StrategyExecutor}
import engine.strategy.model.CompositeStrategy
import engine.strategy.trace.{StrategyTrace, TraceEvent}

object FallbackExecutor extends CompositionExecutor:
  def execute(
    strategy: CompositeStrategy,
    context: ProblemContext,
    budget: ExecutionBudget,
    executor: StrategyExecutor
  ): ExecutionResult =
    val baseTrace = StrategyTrace.empty.append(TraceEvent.CompositeEntered(strategy.id, strategy.compositionMode))

    if strategy.children.isEmpty then
      ExecutionResult.failure(context, baseTrace, ExecutionError.EmptyComposite("Fallback has no children"), budget)
    else
      var trace = baseTrace
      var currentBudget = budget
      var lastError: Option[ExecutionError] = None

      strategy.children.foreach { child =>
        if lastError.isDefined || trace.nonEmpty then ()
      }

      def loop(children: Vector[engine.strategy.model.Strategy], b: ExecutionBudget, t: StrategyTrace): ExecutionResult =
        children.headOption match
          case None =>
            ExecutionResult.failure(context, t, lastError.getOrElse(ExecutionError.EmptyComposite("All fallback children failed")), b)
          case Some(child) =>
            val result = executor.execute(child, context, b)
            val combinedTrace = t ++ result.trace
            if result.success then result.copy(trace = combinedTrace)
            else
              lastError = result.error
              loop(children.tail, result.remainingBudget, combinedTrace)

      loop(strategy.children, currentBudget, trace)
