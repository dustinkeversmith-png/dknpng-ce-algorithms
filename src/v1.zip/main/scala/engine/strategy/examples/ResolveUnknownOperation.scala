package engine.strategy.examples

import engine.context.{ProblemContext, ProblemContextDelta}
import engine.strategy.execution.ExecutionError
import engine.strategy.model.StrategyOperation

final case class ResolveUnknownOperation(id: String, unknownKey: String, factKey: String) extends StrategyOperation:
  override def description: String = s"Resolve unknown $unknownKey into fact $factKey"
  override def run(context: ProblemContext): Either[ExecutionError, ProblemContextDelta] =
    context.unknowns.get(unknownKey) match
      case Some(value) =>
        Right(ProblemContextDelta(
          addFacts = Map(factKey -> value),
          removeUnknowns = Set(unknownKey)
        ))
      case None =>
        Left(ExecutionError.OperationFailed(id, s"Unknown not found: $unknownKey"))
