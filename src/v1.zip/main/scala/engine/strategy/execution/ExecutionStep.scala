package engine.strategy.execution

import engine.context.ProblemContext
import engine.strategy.model.StrategyId

final case class ExecutionStep(
  strategyId: StrategyId,
  before: ProblemContext,
  after: ProblemContext,
  result: Either[ExecutionError, ProblemContext]
)
