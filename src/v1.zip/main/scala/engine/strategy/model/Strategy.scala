package engine.strategy.model

sealed trait Strategy:
  def id: StrategyId
  def name: String
  def kind: StrategyKind
  def capabilities: Set[StrategyCapability]

final case class AtomicStrategy(
  id: StrategyId,
  name: String,
  kind: StrategyKind,
  operationId: String,
  inputKeys: Set[String] = Set.empty,
  outputKeys: Set[String] = Set.empty,
  capabilities: Set[StrategyCapability] = Set.empty
) extends Strategy

final case class CompositeStrategy(
  id: StrategyId,
  name: String,
  kind: StrategyKind,
  compositionMode: CompositionMode,
  children: Vector[Strategy],
  capabilities: Set[StrategyCapability] = Set.empty,
  repeatLimit: Option[Int] = None
) extends Strategy
