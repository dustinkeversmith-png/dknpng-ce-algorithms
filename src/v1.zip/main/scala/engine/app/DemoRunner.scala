package engine.app

import engine.context.{ContextValue, ProblemContext}
import engine.strategy.examples.ExampleRegistries
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.model.*

object DemoRunner:
  def main(args: Array[String]): Unit =



    // This context seems like an okay, but target should exclusivley be part of a goal, and there should be some distinction between
    // inputs and outputs in the problem
    // So the goal should really tell the problem context what its trying to find, and also like we need more context behind the data types behind
    // the inputs so such that there is either like a list of a,b,c,d which are generic types with compares etc 
    // since the concept is to find a algorithm which solves for any type by being able to find the best solution with real data but the
    // problem description is just a generic placeholder.
    val context = ProblemContext(
      facts = Map(
        "candidates" -> ContextValue.list("a", "b", "c", "d"),
        "target" -> ContextValue.StringValue("c")
      )
    )


    // Of course the strategy here is modeled in this such a way

    // ProblemSolution 
    // StrategyTopology - 
    // The strategy topology is built
    // Inside of the strategy is - [operation topology] - which could be a series of steps eg done on the data.
    val assembly = CompositeStrategy(
      id = StrategyId("finite-search-assembly"),
      name = "Finite Search Assembly",

      // Strategy kind here.
      kind = StrategyKind.Search,
      compositionMode = CompositionMode.Sequence,
      children = Vector(

        // So this strategy more or less actually acts on the problem context space rather than the solution itself, so these assembly strategies
        // actually dont have anything to do with the solution topology but introducing or manipulating the problem context which is not ideal, so I guess the strategies here
        // are exclusively going to be known for this context, then a seperate operational assembly should then be assembled or begin to be finding the algorithm
        AtomicStrategy(StrategyId("add-type"), "Add problem type", StrategyKind.Meta, "add-problem-type", capabilities = Set(StrategyCapability.AddsFact)),
        AtomicStrategy(StrategyId("add-subgoal"), "Generate search subgoal", StrategyKind.Meta, "generate-search-subgoal", capabilities = Set(StrategyCapability.GeneratesGoal)),
        AtomicStrategy(StrategyId("search"), "Basic search", StrategyKind.Search, "basic-search", capabilities = Set(StrategyCapability.SearchesCandidates, StrategyCapability.AddsFact))
      )
    )


    // Going to have add a test section here wit hthe new strategies, operations, and step paradigms and tests for creating the topologies of these
    

    
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)

    // And then instead of executing here the assembly you would then use a explorer 
    // which then adequetly epoch trains and assembles steps, and solution strategies, operations and substep topology
    // while in this exterior layer the explorer could be used to try adding different facts or goals or changing the problem context.
    val result = executor.execute(assembly, context, ExecutionBudget(maxSteps = 20, maxDepth = 10))

    println(s"success: ${result.success}")
    println(s"problem.type: ${result.context.facts.get("problem.type")}")
    println(s"search.result: ${result.context.facts.get("search.result")}")
    println(s"goals: ${result.context.goals.mkString(", ")}")
    println(s"trace events: ${result.trace.size}")
