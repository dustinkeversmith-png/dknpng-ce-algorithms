package engine.strategy.composition

import engine.context.ProblemContext
import engine.strategy.execution.{ExecutionBudget, ExecutionError, ExecutionResult, StrategyExecutor}
import engine.strategy.model.CompositeStrategy
import engine.strategy.trace.{StrategyTrace, TraceEvent}

object ChoiceExecutor extends CompositionExecutor:
  def execute(
    strategy: CompositeStrategy,
    context: ProblemContext,
    budget: ExecutionBudget,
    executor: StrategyExecutor
  ): ExecutionResult =
    val baseTrace = StrategyTrace.empty.append(TraceEvent.CompositeEntered(strategy.id, strategy.compositionMode))

    strategy.children.headOption match
      case None =>
        ExecutionResult.failure(context, baseTrace, ExecutionError.EmptyComposite("Choice has no children"), budget)
      case Some(selected) =>
        val selectedTrace = baseTrace.append(TraceEvent.ChoiceSelected(strategy.id, selected.id))
        val result = executor.execute(selected, context, budget)
        result.copy(trace = selectedTrace ++ result.trace)
