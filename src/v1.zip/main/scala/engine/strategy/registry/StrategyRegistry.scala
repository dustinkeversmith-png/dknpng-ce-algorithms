package engine.strategy.registry

import engine.strategy.model.{Strategy, StrategyId}

final case class StrategyRegistry(
  strategies: Map[StrategyId, Strategy] = Map.empty
):
  def register(strategy: Strategy): Either[String, StrategyRegistry] =
    if strategies.contains(strategy.id) then Left(s"Strategy already registered: ${strategy.id.value}")
    else Right(copy(strategies = strategies + (strategy.id -> strategy)))

  def registerUnsafe(strategy: Strategy): StrategyRegistry =
    copy(strategies = strategies + (strategy.id -> strategy))

  def get(id: StrategyId): Option[Strategy] = strategies.get(id)

object StrategyRegistry:
  val empty: StrategyRegistry = StrategyRegistry()
