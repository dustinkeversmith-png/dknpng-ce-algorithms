package engine.strategy.composition

import engine.context.ProblemContext
import engine.strategy.execution.{ExecutionBudget, ExecutionResult, StrategyExecutor}
import engine.strategy.model.CompositeStrategy
import engine.strategy.trace.{StrategyTrace, TraceEvent}

object SequenceExecutor extends CompositionExecutor:
  def execute(
    strategy: CompositeStrategy,
    context: ProblemContext,
    budget: ExecutionBudget,
    executor: StrategyExecutor
  ): ExecutionResult =
    val startTrace = StrategyTrace.empty
      .append(TraceEvent.CompositeEntered(strategy.id, strategy.compositionMode))

    strategy.children.foldLeft(ExecutionResult.success(context, startTrace, budget)) { (acc, child) =>
      if !acc.success then acc
      else
        val childResult = executor.execute(child, acc.context, acc.remainingBudget)
        childResult.copy(trace = acc.trace ++ childResult.trace)
    }
