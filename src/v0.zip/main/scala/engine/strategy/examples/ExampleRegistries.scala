package engine.strategy.examples

import engine.context.ContextValue
import engine.strategy.registry.OperationRegistry

object ExampleRegistries:
  val finiteSearchOperations: OperationRegistry = OperationRegistry.withOperations(
    AddFactOperation("add-problem-type", "problem.type", ContextValue.StringValue("finite-search")),
    GenerateSubgoalOperation("generate-search-subgoal", "search candidates"),
    BasicSearchOperation("basic-search", "candidates", "target", "search.result"),
    ResolveUnknownOperation("resolve-target", "target", "target"),
    FailOperation("fail", "Intentional fallback test failure")
  )
