package engine.strategy.model

final case class StrategyAssembly(
  id: StrategyId,
  name: String,
  root: Strategy
)
