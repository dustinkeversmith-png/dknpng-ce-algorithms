package engine.problem

import engine.context.{ContextValue, ProblemContext}
import JsonValue.*


// This context value codec should probably be placed in a parsing sub folder under json, same with the other parsing jsons
object JsonContextValueCodec:
  def toContextValue(json: JsonValue): ContextValue =
    json match
      case JsonString(value) => ContextValue.StringValue(value)
      case JsonNumber(value) if value.isValidInt => ContextValue.IntValue(value.toInt)
      case JsonNumber(value) => ContextValue.DoubleValue(value.toDouble)
      case JsonBoolean(value) => ContextValue.BooleanValue(value)
      case JsonNull => ContextValue.NullValue
      case JsonArray(values) => ContextValue.ListValue(values.map(toContextValue))
      case JsonObject(values) =>
        decodeTaggedContextValue(values).getOrElse(ContextValue.MapValue(values.view.mapValues(toContextValue).toMap))

  def toProblemContext(json: JsonValue): Either[ProblemFormatError, ProblemContext] =
    json match
      case JsonObject(values) if values.contains("facts") || values.contains("unknowns") || values.contains("goals") || values.contains("artifacts") =>
        for
          facts <- objectField(values, "facts").map(_.view.mapValues(toContextValue).toMap)
          unknowns <- objectField(values, "unknowns").map(_.view.mapValues(toContextValue).toMap)
          goals <- stringVectorField(values, "goals")
          artifacts <- objectField(values, "artifacts").map(_.view.mapValues(toContextValue).toMap)
        yield ProblemContext(facts, unknowns, goals, artifacts)
      case other => Left(ProblemFormatError("Expected a ProblemContext JSON object with facts/unknowns/goals/artifacts"))

  private def decodeTaggedContextValue(values: Map[String, JsonValue]): Option[ContextValue] =
    if values.size != 1 then None
    else values.head match
      case ("StringValue", JsonString(value)) => Some(ContextValue.StringValue(value))
      case ("IntValue", JsonNumber(value)) if value.isValidInt => Some(ContextValue.IntValue(value.toInt))
      case ("DoubleValue", JsonNumber(value)) => Some(ContextValue.DoubleValue(value.toDouble))
      case ("BooleanValue", JsonBoolean(value)) => Some(ContextValue.BooleanValue(value))
      case ("ListValue", JsonArray(items)) => Some(ContextValue.ListValue(items.map(toContextValue)))
      case ("MapValue", JsonObject(items)) => Some(ContextValue.MapValue(items.view.mapValues(toContextValue).toMap))
      case ("ArtifactValue", JsonObject(items)) =>
        val kind = items.get("kind").collect { case JsonString(value) => value }
        val artifactValues = items.get("values").collect { case JsonObject(v) => v.view.mapValues(toContextValue).toMap }
        for k <- kind; v <- artifactValues yield ContextValue.ArtifactValue(k, v)
      case ("NullValue", _) => Some(ContextValue.NullValue)
      case _ => None

  private def objectField(values: Map[String, JsonValue], key: String): Either[ProblemFormatError, Map[String, JsonValue]] =
    values.get(key) match
      case None => Right(Map.empty)
      case Some(JsonObject(fields)) => Right(fields)
      case Some(_) => Left(ProblemFormatError(s"Expected object field '$key'"))

  private def stringVectorField(values: Map[String, JsonValue], key: String): Either[ProblemFormatError, Vector[String]] =
    values.get(key) match
      case None => Right(Vector.empty)
      case Some(JsonArray(items)) =>
        val strings = items.collect { case JsonString(value) => value }
        if strings.size == items.size then Right(strings)
        else Left(ProblemFormatError(s"Expected '$key' to contain only strings"))
      case Some(_) => Left(ProblemFormatError(s"Expected array field '$key'"))
