package engine.strategy.composition

import engine.context.ProblemContext
import engine.strategy.execution.{ExecutionBudget, ExecutionError, ExecutionResult, StrategyExecutor}
import engine.strategy.model.CompositeStrategy
import engine.strategy.trace.{StrategyTrace, TraceEvent}

object RepeatExecutor extends CompositionExecutor:
  def execute(
    strategy: CompositeStrategy,
    context: ProblemContext,
    budget: ExecutionBudget,
    executor: StrategyExecutor
  ): ExecutionResult =
    val baseTrace = StrategyTrace.empty.append(TraceEvent.CompositeEntered(strategy.id, strategy.compositionMode))
    val limit = strategy.repeatLimit.getOrElse(1)

    strategy.children.headOption match
      case None =>
        ExecutionResult.failure(context, baseTrace, ExecutionError.EmptyComposite("Repeat has no child"), budget)
      case Some(child) =>
        def loop(iteration: Int, ctx: ProblemContext, b: ExecutionBudget, trace: StrategyTrace): ExecutionResult =
          if iteration >= limit then ExecutionResult.success(ctx, trace, b)
          else
            val iterationTrace = trace.append(TraceEvent.RepeatIteration(strategy.id, iteration + 1))
            val result = executor.execute(child, ctx, b)
            val combinedTrace = iterationTrace ++ result.trace
            if result.success then loop(iteration + 1, result.context, result.remainingBudget, combinedTrace)
            else result.copy(trace = combinedTrace)

        loop(0, context, budget, baseTrace)
