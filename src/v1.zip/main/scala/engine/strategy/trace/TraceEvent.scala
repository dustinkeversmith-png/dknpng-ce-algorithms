package engine.strategy.trace

import engine.context.ProblemContextDelta
import engine.strategy.model.{CompositionMode, StrategyId}

sealed trait TraceEvent:
  def strategyId: StrategyId

object TraceEvent:
  final case class StrategyStarted(strategyId: StrategyId, name: String) extends TraceEvent
  final case class StrategySucceeded(strategyId: StrategyId) extends TraceEvent
  final case class StrategyFailed(strategyId: StrategyId, reason: String) extends TraceEvent
  final case class DeltaApplied(strategyId: StrategyId, delta: ProblemContextDelta) extends TraceEvent
  final case class BudgetConsumed(strategyId: StrategyId, remainingSteps: Int, currentDepth: Int) extends TraceEvent
  final case class CompositeEntered(strategyId: StrategyId, mode: CompositionMode) extends TraceEvent
  final case class ChoiceSelected(strategyId: StrategyId, selectedChildId: StrategyId) extends TraceEvent
  final case class RepeatIteration(strategyId: StrategyId, iteration: Int) extends TraceEvent
