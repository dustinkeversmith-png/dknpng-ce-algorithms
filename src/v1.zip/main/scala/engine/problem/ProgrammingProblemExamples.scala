package engine.problem

// So in here the nums array shouldn't be like a hard coded integer value, but instead a generic descriptor of the input type
// possibly lengths etc
// Same with the other descriptiors of a programming problem example, and so the goals should also be more robust

object ProgrammingProblemExamples:
  val twoSumJsonic: String =
    """
    {
      // JSONic conveniences are supported: comments and trailing commas.
      "id": "two-sum-basic",
      "kind": "algorithm",
      "domain": "arrays",
      "title": "Two Sum",
      "description": "Given an array of integers and a target, return indices of two numbers that add up to the target.",
      "input.spec": {
        "nums": "Array[Int]",
        "target": "Int"
      },
      "output.spec": "Array[Int] of length 2 containing the selected indices",
      "constraints": [
        "Exactly one valid answer exists",
        "Cannot use the same element twice",
        "Expected O(n) time",
      ],
      "examples": [
        {
          "input": { "nums": [2, 7, 11, 15], "target": 9 },
          "output": [0, 1],
          "explanation": "nums[0] + nums[1] = 9"
        }
      ],
      "complexity.target": {
        "time": "O(n)",
        "space": "O(n)"
      }
    }
    """
