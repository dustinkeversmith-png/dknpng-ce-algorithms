package engine.strategy.execution

final case class ExecutionBudget(
  maxSteps: Int,
  maxDepth: Int,
  currentDepth: Int = 0
):
  def remainingSteps: Int = maxSteps

  def consumeStep: Either[ExecutionError, ExecutionBudget] =
    if maxSteps <= 0 then Left(ExecutionError.BudgetExceeded("No execution steps remaining"))
    else Right(copy(maxSteps = maxSteps - 1))

  def enterDepth: Either[ExecutionError, ExecutionBudget] =
    if currentDepth + 1 > maxDepth then
      Left(ExecutionError.DepthExceeded(s"Max execution depth exceeded: $maxDepth"))
    else
      Right(copy(currentDepth = currentDepth + 1))

  def exitDepth: ExecutionBudget =
    copy(currentDepth = math.max(0, currentDepth - 1))
