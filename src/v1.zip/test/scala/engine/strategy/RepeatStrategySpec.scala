package engine.strategy

import engine.context.ProblemContext
import engine.strategy.examples.ExampleRegistries
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.model.*
import engine.strategy.trace.TraceEvent

class RepeatStrategySpec extends munit.FunSuite:
  test("repeats child fixed number of times"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val strategy = CompositeStrategy(
      StrategyId("repeat"), "Repeat", StrategyKind.Meta, CompositionMode.Repeat,
      Vector(AtomicStrategy(StrategyId("subgoal"), "subgoal", StrategyKind.Meta, "generate-search-subgoal")),
      repeatLimit = Some(3)
    )

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(10, 10))

    assert(result.success)
    assertEquals(result.context.goals.size, 3)
    assertEquals(result.trace.events.count(_.isInstanceOf[TraceEvent.RepeatIteration]), 3)

  test("stops on budget exhaustion"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val strategy = CompositeStrategy(
      StrategyId("repeat-budget"), "Repeat", StrategyKind.Meta, CompositionMode.Repeat,
      Vector(AtomicStrategy(StrategyId("subgoal"), "subgoal", StrategyKind.Meta, "generate-search-subgoal")),
      repeatLimit = Some(10)
    )

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(3, 10))
    assert(!result.success)
