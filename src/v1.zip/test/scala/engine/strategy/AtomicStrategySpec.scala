package engine.strategy

import engine.context.{ContextValue, ProblemContext}
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.examples.{AddFactOperation, ExampleRegistries}
import engine.strategy.model.*
import engine.strategy.registry.OperationRegistry

class AtomicStrategySpec extends munit.FunSuite:
  test("executes operation by ID and applies context delta"):
    val registry = OperationRegistry.withOperations(
      AddFactOperation("add-x", "x", ContextValue.StringValue("ok"))
    )
    val executor = StrategyInterpreter(registry)
    val strategy = AtomicStrategy(StrategyId("s1"), "Add x", StrategyKind.Meta, "add-x")

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(5, 5))

    assert(result.success)
    assertEquals(result.context.facts("x"), ContextValue.StringValue("ok"))
    assert(result.trace.nonEmpty)

  test("fails if operation ID is missing"):
    val executor = StrategyInterpreter(OperationRegistry.empty)
    val strategy = AtomicStrategy(StrategyId("missing"), "Missing", StrategyKind.Meta, "does-not-exist")

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(5, 5))

    assert(!result.success)
    assert(result.error.nonEmpty)
