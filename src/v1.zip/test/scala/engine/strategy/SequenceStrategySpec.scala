package engine.strategy

import engine.context.{ContextValue, ProblemContext}
import engine.strategy.examples.ExampleRegistries
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.model.*

class SequenceStrategySpec extends munit.FunSuite:
  test("executes children in order and passes updated context"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val context = ProblemContext(
      facts = Map(
        "candidates" -> ContextValue.list("a", "b", "c"),
        "target" -> ContextValue.StringValue("b")
      )
    )
    val strategy = CompositeStrategy(
      StrategyId("seq"),
      "Sequence",
      StrategyKind.Search,
      CompositionMode.Sequence,
      Vector(
        AtomicStrategy(StrategyId("type"), "type", StrategyKind.Meta, "add-problem-type"),
        AtomicStrategy(StrategyId("search"), "search", StrategyKind.Search, "basic-search")
      )
    )

    val result = executor.execute(strategy, context, ExecutionBudget(10, 10))

    assert(result.success)
    assertEquals(result.context.facts("problem.type"), ContextValue.StringValue("finite-search"))
    assertEquals(result.context.facts("search.result"), ContextValue.StringValue("b"))

  test("fails if child fails"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val strategy = CompositeStrategy(
      StrategyId("seq-fail"), "Sequence Fail", StrategyKind.Search, CompositionMode.Sequence,
      Vector(
        AtomicStrategy(StrategyId("fail-child"), "fail", StrategyKind.Meta, "fail"),
        AtomicStrategy(StrategyId("type"), "type", StrategyKind.Meta, "add-problem-type")
      )
    )

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(10, 10))
    assert(!result.success)
    assert(!result.context.facts.contains("problem.type"))
