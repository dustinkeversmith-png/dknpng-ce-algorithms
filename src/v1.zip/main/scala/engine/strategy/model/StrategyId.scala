package engine.strategy.model

final case class StrategyId(value: String) extends AnyVal:
  override def toString: String = value
