package engine.strategy.model

import engine.context.{ProblemContext, ProblemContextDelta}
import engine.strategy.execution.ExecutionError

// A strategy operation here involves altering the problem and is not a solution based strategy which would contain a detailed
// topology of the steps, and operations and a way to assign the correct inputs that it wants possibly through a factor input router mechanism
trait StrategyOperation:
  def id: String
  def description: String = id
  def run(context: ProblemContext): Either[ExecutionError, ProblemContextDelta]
