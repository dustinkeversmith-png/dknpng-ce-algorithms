package engine.strategy.execution

import engine.context.ProblemContext
import engine.strategy.model.Strategy

trait StrategyExecutor:
  def execute(strategy: Strategy, context: ProblemContext, budget: ExecutionBudget): ExecutionResult
