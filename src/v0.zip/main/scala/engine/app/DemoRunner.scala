package engine.app

import engine.context.{ContextValue, ProblemContext}
import engine.strategy.examples.ExampleRegistries
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.model.*

object DemoRunner:
  def main(args: Array[String]): Unit =
    val context = ProblemContext(
      facts = Map(
        "candidates" -> ContextValue.list("a", "b", "c", "d"),
        "target" -> ContextValue.StringValue("c")
      )
    )

    val assembly = CompositeStrategy(
      id = StrategyId("finite-search-assembly"),
      name = "Finite Search Assembly",
      kind = StrategyKind.Search,
      compositionMode = CompositionMode.Sequence,
      children = Vector(
        AtomicStrategy(StrategyId("add-type"), "Add problem type", StrategyKind.Meta, "add-problem-type", capabilities = Set(StrategyCapability.AddsFact)),
        AtomicStrategy(StrategyId("add-subgoal"), "Generate search subgoal", StrategyKind.Meta, "generate-search-subgoal", capabilities = Set(StrategyCapability.GeneratesGoal)),
        AtomicStrategy(StrategyId("search"), "Basic search", StrategyKind.Search, "basic-search", capabilities = Set(StrategyCapability.SearchesCandidates, StrategyCapability.AddsFact))
      )
    )

    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val result = executor.execute(assembly, context, ExecutionBudget(maxSteps = 20, maxDepth = 10))

    println(s"success: ${result.success}")
    println(s"problem.type: ${result.context.facts.get("problem.type")}")
    println(s"search.result: ${result.context.facts.get("search.result")}")
    println(s"goals: ${result.context.goals.mkString(", ")}")
    println(s"trace events: ${result.trace.size}")
