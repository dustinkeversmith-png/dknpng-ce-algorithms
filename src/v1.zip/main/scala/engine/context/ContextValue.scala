package engine.context

// Context values represent the values that can be stored in the context. They can be of various types, such as strings, integers, booleans, lists, maps, and artifacts. The ContextValue trait provides methods to convert the value to a string or a vector of ContextValues if applicable.
sealed trait ContextValue derives CanEqual:
  def asStringOption: Option[String] = this match
    case ContextValue.StringValue(value) => Some(value)
    case _ => None

  def asVectorOption: Option[Vector[ContextValue]] = this match
    case ContextValue.ListValue(values) => Some(values)
    case _ => None


// Basic Values are values or list.
object ContextValue:
  final case class StringValue(value: String) extends ContextValue
  final case class IntValue(value: Int) extends ContextValue
  final case class DoubleValue(value: Double) extends ContextValue
  final case class BooleanValue(value: Boolean) extends ContextValue
  final case class ListValue(values: Vector[ContextValue]) extends ContextValue
  final case class MapValue(values: Map[String, ContextValue]) extends ContextValue
  final case class ArtifactValue(kind: String, values: Map[String, ContextValue]) extends ContextValue
  case object NullValue extends ContextValue

  def string(value: String): ContextValue = StringValue(value)
  def int(value: Int): ContextValue = IntValue(value)
  def bool(value: Boolean): ContextValue = BooleanValue(value)
  def list(values: String*): ContextValue = ListValue(values.toVector.map(StringValue.apply))
