package engine.context

final case class ProblemContext(
  // Known facts possible inputs to a problem context would be interesting.
  facts: Map[String, ContextValue] = Map.empty,
  // Not sure why an unknown value would map to a context value but should instead kind of map to a place in the problem context.
  unknowns: Map[String, ContextValue] = Map.empty,
  goals: Vector[String] = Vector.empty,
  // Goals are currently only strings and do not have a concrete implementation behind them.
  artifacts: Map[String, ContextValue] = Map.empty
):
  def applyDelta(delta: ProblemContextDelta): ProblemContext =


    // What else would be edited in a problem context, and why would the facts change, the facts would only change when being prompted to be
    // given a hint or discovering an unknown. The unknowns know are kind of modeled as this is unknown but the unkonnw is not clear on how it should
    // be received.

    // Unknowns should be modeled as a part of the problem context which is missing

    // For example you could have a strategy some facts and maybe want to find a goal.. etc so that would be for exclusively for the "ProblemGraph" or solution inverting system/.

    val removedFacts = facts -- delta.removeFacts
    val removedUnknowns = unknowns -- delta.removeUnknowns
    copy(
      facts = removedFacts ++ delta.addFacts,
      unknowns = removedUnknowns ++ delta.addUnknowns,
      goals = goals ++ delta.addGoals,
      artifacts = artifacts ++ delta.addArtifacts
    )

  def fact(key: String): Option[ContextValue] = facts.get(key)
  def unknown(key: String): Option[ContextValue] = unknowns.get(key)
  def artifact(key: String): Option[ContextValue] = artifacts.get(key)
