package engine.strategy.model

enum StrategyKind:
  case Classical
  case Symbolic
  case Search
  case Simulation
  case Translation
  case Quantum
  case Hybrid
  case Meta
