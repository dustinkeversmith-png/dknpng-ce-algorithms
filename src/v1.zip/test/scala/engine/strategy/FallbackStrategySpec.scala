package engine.strategy

import engine.context.{ContextValue, ProblemContext}
import engine.strategy.examples.ExampleRegistries
import engine.strategy.execution.{ExecutionBudget, StrategyInterpreter}
import engine.strategy.model.*

class FallbackStrategySpec extends munit.FunSuite:
  test("tries fallback when first child fails"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val strategy = CompositeStrategy(
      StrategyId("fallback"), "Fallback", StrategyKind.Meta, CompositionMode.Fallback,
      Vector(
        AtomicStrategy(StrategyId("fail-child"), "fail", StrategyKind.Meta, "fail"),
        AtomicStrategy(StrategyId("type"), "type", StrategyKind.Meta, "add-problem-type")
      )
    )

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(10, 10))

    assert(result.success)
    assertEquals(result.context.facts("problem.type"), ContextValue.StringValue("finite-search"))

  test("fails only if all children fail"):
    val executor = StrategyInterpreter(ExampleRegistries.finiteSearchOperations)
    val strategy = CompositeStrategy(
      StrategyId("fallback-all-fail"), "Fallback", StrategyKind.Meta, CompositionMode.Fallback,
      Vector(
        AtomicStrategy(StrategyId("fail-a"), "fail a", StrategyKind.Meta, "fail"),
        AtomicStrategy(StrategyId("fail-b"), "fail b", StrategyKind.Meta, "fail")
      )
    )

    val result = executor.execute(strategy, ProblemContext(), ExecutionBudget(10, 10))
    assert(!result.success)
