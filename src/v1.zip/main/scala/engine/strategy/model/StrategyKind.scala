package engine.strategy.model

// Here what is the purpose of have a search when it seems like the strategy kind includes meta labeling which doesn't describe
// the action of the strategy but its applicability, possibly adding a new class called StrategyCompatability with a 
// instruction type such thing.

enum StrategyKind:
  case Classical
  case Symbolic
  case Search
  case Simulation
  case Translation
  case Quantum
  case Hybrid
  case Meta
