package engine.strategy.model

enum CompositionMode:
  case Sequence
  case Fallback
  case Choice
  case Repeat
  case Parallel
  case MeasureThenSelect
  case Recursive
