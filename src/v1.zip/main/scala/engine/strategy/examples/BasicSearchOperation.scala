package engine.strategy.examples

import engine.context.{ContextValue, ProblemContext, ProblemContextDelta}
import engine.strategy.execution.ExecutionError
import engine.strategy.model.StrategyOperation


// A operation on this scale should that have granula steps, so instead of one big function
// It would probably contain a toplogy like for example filled with tons of mini steps which might include
// Loop steps and then inside of those you can append or assembly the order of sub steps so much that for example the system could
// End up combinatorially developing something like merge sort.
final case class BasicSearchOperation(
  id: String,
  candidatesKey: String,
  targetKey: String,
  resultKey: String
) extends StrategyOperation:
  override def description: String = s"Search $candidatesKey for $targetKey"

  override def run(context: ProblemContext): Either[ExecutionError, ProblemContextDelta] =
    (context.facts.get(candidatesKey), context.facts.get(targetKey)) match
      case (Some(ContextValue.ListValue(candidates)), Some(target)) =>
        candidates.find(_ == target) match
          case Some(found) => Right(ProblemContextDelta(addFacts = Map(resultKey -> found)))
          case None => Left(ExecutionError.OperationFailed(id, "Target was not found in candidate list"))
      case (None, _) => Left(ExecutionError.OperationFailed(id, s"Missing candidates fact: $candidatesKey"))
      case (_, None) => Left(ExecutionError.OperationFailed(id, s"Missing target fact: $targetKey"))
      case (Some(other), _) => Left(ExecutionError.OperationFailed(id, s"Candidates value must be ListValue, got $other"))
