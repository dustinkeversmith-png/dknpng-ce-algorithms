package engine.strategy.examples

import engine.context.{ProblemContext, ProblemContextDelta}
import engine.strategy.execution.ExecutionError
import engine.strategy.model.StrategyOperation

final case class GenerateSubgoalOperation(id: String, goal: String) extends StrategyOperation:
  override def description: String = s"Generate subgoal: $goal"
  override def run(context: ProblemContext): Either[ExecutionError, ProblemContextDelta] =
    Right(ProblemContextDelta(addGoals = Vector(goal)))
